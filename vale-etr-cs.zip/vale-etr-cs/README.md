# ETR-cs – Vale styl pro snadné čtení

Styl pro [Vale](https://vale.sh) kontroluje české texty ve formátu **snadného čtení**
(Easy to Read, ETR). Vychází z Metodiky Easy to Read MV ČR (2019) a z Evropských pravidel
Inclusion Europe. Doplňuje skill [etr](https://www.michalrada.cz/snadne-cteni-etr-skill).

## Obsah

```
.vale.ini              konfigurace
styles/ETR-cs/         pravidla (1 soubor = 1 pravidlo)
priklady/dobry.md      text, který projde bez chyb
priklady/spatny.md     text se všemi typickými chybami
```

## Instalace a použití

1. Nainstalujte Vale: https://vale.sh/docs/install
2. Složku `styles/ETR-cs` a soubor `.vale.ini` zkopírujte do kořene repozitáře.
3. Spusťte kontrolu:

```bash
vale text.md
vale priklady/spatny.md   # ukázka
```

Když už `.vale.ini` máte, stačí do něj přidat `ETR-cs` do `BasedOnStyles`.

## Úrovně

- **error** znamená porušení pravidla. Oprava je povinná.
- **warning** znamená podezření. Posuďte ho a většinou opravte.
- **suggestion** je jen doporučení.

## Pravidla

| Pravidlo | Úroveň | Co kontroluje |
|---|---|---|
| UvodniVeta | error | Text začíná větou „Toto je verze ve snadno čitelném textu.“ |
| DelkaVety | error | Věta má nejvýš 15 slov. |
| DelkaOdstavce | error | Odstavec má nejvýš 5 vět. |
| VetaNaRadek | error | Každá věta je na novém řádku. |
| Zkratky | error | Žádné zkratky (např., atd., tj., cca…). |
| Koruny | error | „korun“ místo „Kč“ a „,-“. |
| Procenta | error | Žádná procenta. |
| RimskeCislice | error | Žádné římské číslice. |
| DatumCislem | error | Datum s měsícem slovy. |
| Krat | error | „3krát“ místo „3x“. |
| Zavorky | error | Žádné závorky. |
| Strednik | error | Žádné středníky. |
| Znaky | error | Žádné znaky §, &, \, <, >, #. |
| Kurziva | error | Žádná kurzíva ani podtržení. |
| PoznamkyPodCarou | error | Žádné poznámky pod čarou. |
| DelkaNadpisu | error | Nadpis má nejvýš 10 slov. |
| VnoreneOdrazky | error | Žádné vnořené odrážky. |
| Nahrady | warning | Úřední a cizí slova a jejich jednodušší náhrady. |
| Pasiv | warning | Trpný rod („bude zasláno“). |
| ZvratnyPasiv | warning | Zvratný pasiv („se podává“). |
| Carky | warning | Víc než 1 čárka ve větě. |
| Verzalky | warning | Slova velkými písmeny. |
| UrovenNadpisu | warning | Nejvýš 2 úrovně nadpisů. |
| RadovaCislovka | warning | „sedmá schůzka“ místo „7. schůzka“. |
| DlouheOdkazy | warning | Dlouhé adresy schované pod text odkazu. |
| Konzistence | warning | Jednotné tvary (e-mail / email). |
| Zapor | suggestion | Záporné věty. |
| VelkaCisla | suggestion | Velká čísla. |
| DlouheSlovo | suggestion | Slova delší než 17 písmen. |
| Uvozovky | suggestion | Uvozovky jen u názvů a přímé řeči. |

## Úpravy

- **Jiná úvodní věta:** změňte proměnnou `veta` v `UvodniVeta.yml`.
- **Jiný limit délky věty:** změňte `max` v `DelkaVety.yml`.
- **Vlastní náhrady slov:** doplňte je do `swap` v `Nahrady.yml`. Klíč je regulární výraz.
- **Vypnutí pravidla:** v `.vale.ini` přidejte například `ETR-cs.Zapor = NO`.

## GitHub Actions

```yaml
name: ETR
on: [pull_request]
jobs:
  vale:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: vale-cli/vale-action@v2
        with:
          files: texty/
```

## Omezení

Vale kontroluje formu textu, ne jeho význam. Nepozná, jestli:
- text obsahuje všechny důležité údaje z originálu,
- je každé těžké slovo vysvětlené,
- je tón dospělý a srozumitelný.

Pasiv a zápory hledá podle vzorů, takže může něco přehlédnout nebo označit omylem.
Typografii souborů DOCX a PDF (písmo, velikost, zarovnání) nekontroluje.

## Zdroje

- [Metodika Easy to Read, MV ČR 2019](https://kvalitavs.gov.cz/metodiky-dokumenty-a-publikace/easy-to-read-etr/)
- [Informace pro všechny – Evropská pravidla (Inclusion Europe)](https://www.inclusion-europe.eu/wp-content/uploads/2017/06/CZ_Information_for_all.pdf)

## Licence a autor

[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.cs) · Michal Rada ·
[web](https://www.michalrada.cz/snadne-cteni-etr-skill) ·
[repozitář](https://github.com/egdilna/snadne-cteni-etr-skill)

Testováno s Vale 3.22.0.
