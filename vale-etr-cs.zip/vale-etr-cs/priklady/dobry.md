Toto je verze ve snadno čitelném textu.
Vychází z dokumentu Oznámení o přerušení dodávky vody.

# Ve čtvrtek 3. prosince 2026 nepoteče voda

## Kdy nepoteče voda

Ve čtvrtek 3. prosince 2026.
Od 8 hodin ráno do 2 hodin odpoledne.

## Kde dostanete vodu

Před domem Lipová 12 bude stát cisterna.
Cisterna je velké auto s nádrží na vodu.
Z cisterny si můžete vzít pitnou vodu.

## Kdo vám pomůže

- Telefon: 974 816 597
- E-mail: info@voda.cz
