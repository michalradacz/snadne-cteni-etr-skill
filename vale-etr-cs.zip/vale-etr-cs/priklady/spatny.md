# Oznámení

Žadatel je povinen nejpozději do 15. 11. 2026 předložit doklad o úhradě poplatku (500,- Kč), jinak bude řízení zastaveno dle § 66. Formulář se podává osobně; např. na přepážce.

Příspěvek pobírá 63 % oprávněných osob, tj. cca 1 758 000 osob, a to již 3x v XII. měsíci.

### Poznámky

  - vnořená odrážka s *kurzívou*
