# ETR-en – Vale style for easy-to-read text

A [Vale](https://vale.sh) style that checks English texts written in **easy-to-read**
format (ETR). It is based on the European standards *Information for all* by Inclusion Europe
and on the Easy to Read methodology of the Czech Ministry of the Interior (2019).
It complements the [etr skill](https://www.michalrada.cz/snadne-cteni-etr-skill).

## Contents

```
.vale.ini              configuration
styles/ETR-en/         rules (1 file = 1 rule)
examples/good.md       text that passes with no alerts
examples/bad.md        text with typical mistakes
```

## Installation and use

1. Install Vale: https://vale.sh/docs/install
2. Copy the `styles/ETR-en` folder and the `.vale.ini` file to the root of your repository.
3. Run the check:

```bash
vale text.md
vale examples/bad.md   # demo
```

If you already have a `.vale.ini`, add `ETR-en` to `BasedOnStyles`.

## Levels

- **error** means a rule is broken and must be fixed.
- **warning** means a likely problem. Review it and usually fix it.
- **suggestion** is a recommendation only.

## Rules

| Rule | Level | What it checks |
|---|---|---|
| IntroSentence | error | The text starts with “This is the easy-to-read version of the text.” |
| SentenceLength | error | A sentence has at most 15 words. |
| ParagraphLength | error | A paragraph has at most 5 sentences. |
| OneSentencePerLine | error | Every sentence starts on a new line. |
| Abbreviations | error | No abbreviations (e.g., i.e., etc., approx.…). |
| Percentages | error | No percentages. |
| RomanNumerals | error | No Roman numerals. |
| NumericDates | error | Dates with the month as a word. |
| Times | error | “3 times”, not “3x”. |
| Brackets | error | No brackets. |
| Semicolons | error | No semicolons. |
| Symbols | error | No §, &, \, <, >, #. |
| Italics | error | No italics or underlining. |
| Footnotes | error | No footnotes. |
| HeadingLength | error | A heading has at most 10 words. |
| NestedLists | error | No nested lists. |
| Substitutions | warning | Formal words and their plain replacements. |
| Passive | warning | Passive voice. |
| Commas | warning | More than 1 comma in a sentence. |
| AllCaps | warning | Words in capital letters. |
| HeadingLevels | warning | At most 2 heading levels. |
| Idioms | warning | Metaphors and idioms. |
| LongLinks | warning | Long web addresses hidden under link text. |
| Consistency | warning | One form for the same thing (email / e-mail). |
| Readability | warning | Flesch-Kincaid grade 6 or lower. |
| Negatives | suggestion | Negative sentences. |
| BigNumbers | suggestion | Big numbers. |
| LongWords | suggestion | Words longer than 13 letters. |
| Quotes | suggestion | Quotation marks only for names and direct speech. |

## Customisation

- **Different intro sentence:** change the `intro` variable in `IntroSentence.yml`.
- **Different sentence limit:** change `max` in `SentenceLength.yml`.
- **Your own word list:** add entries to `swap` in `Substitutions.yml`. Keys are regular expressions.
- **Turn a rule off:** add, for example, `ETR-en.Negatives = NO` to `.vale.ini`.

## GitHub Actions

```yaml
name: ETR
on: [pull_request]
jobs:
  vale:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: vale-cli/vale-action@v2
        with:
          files: texts/
```

## Limitations

Vale checks the form of the text, not its meaning. It cannot tell:
- if the text keeps all important facts from the original,
- if every difficult word is explained,
- if the tone is adult and clear.

The passive and negative rules use patterns, so they can miss cases or flag false alarms.
It does not check the layout of DOCX or PDF files, such as font, size or alignment.

## Sources

- [Information for all – European standards (Inclusion Europe)](https://www.inclusion-europe.eu/easy-to-read-standards-guidelines/)
- [Easy to Read methodology, Czech Ministry of the Interior 2019](https://kvalitavs.gov.cz/metodiky-dokumenty-a-publikace/easy-to-read-etr/)

## Licence and author

[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · Michal Rada ·
[website](https://www.michalrada.cz/snadne-cteni-etr-skill) ·
[repository](https://github.com/egdilna/snadne-cteni-etr-skill)

Tested with Vale 3.22.0.
