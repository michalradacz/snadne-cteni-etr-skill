# Notice

Applicants are required to submit proof of payment (EUR 50) prior to 15/11/2026; otherwise the application will be rejected, e.g. in accordance with section 66. The form is submitted in person.

Approximately 63 % of eligible persons, i.e. 1,758,000 people, receive the benefit 3x a year in PART XII.

### Notes

  - nested item with *italics*
