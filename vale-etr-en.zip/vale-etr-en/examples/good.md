This is the easy-to-read version of the text.
It comes from the document Water supply interruption notice.

# There will be no water on Thursday 3 December 2026

## When there will be no water

On Thursday 3 December 2026.
From 8 in the morning to 2 in the afternoon.

## Where you can get water

A water tank will stand in front of 12 Lime Street.
A water tank is a big car with water in it.
You can take drinking water from the tank.

## Who can help you

- Phone: 0800 123 456
- Email: info@water.org
